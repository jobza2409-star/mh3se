# MH3SE Online deployment patch (prototype)

This patch adapts the existing Rust/Axum web UI to run as a hosted web service.
It is a proposed patch, not a verified release: this environment could not download/build the full upstream repository or test against a real MH Tri save file.

## Apply on a fork of https://github.com/JeSuisSurGithub/mh3se

1. Replace `src/main-ui.rs` with the file in this patch.
2. In `Cargo.toml`, add this line under `[dependencies]`:

   `tempfile = "3"`

3. Add `Dockerfile` from this patch at the repository root.
4. Commit the changes to your fork.
5. In Render, create a new **Web Service** from your fork, choose **Docker** as the runtime, and deploy. The service reads Render's `PORT` environment variable and binds to `0.0.0.0`.
6. Open the deployed HTTPS URL and test with a COPY of a real `data00` file. Never use your only save copy.

## Important test status and limitations

- The code was not compiled or run here because the execution environment could not reach GitHub to obtain the full source tree.
- The patch uses a unique temporary directory per request and removes it automatically, validates slots 0-2, limits uploaded binary files to 16 MiB, and limits HTTP request bodies to 32 MiB.
- Before sharing the service publicly, add rate limiting/abuse protection and review error handling. Do not upload private or irreplaceable saves to an untrusted host.
- After a build, first verify that loading a known-good save succeeds. Then build an unchanged save to a *new* output file and compare its size and hash; finally test an edited copy and verify it in Dolphin. Never overwrite the original.

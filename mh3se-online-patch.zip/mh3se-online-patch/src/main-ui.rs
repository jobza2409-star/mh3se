use axum::{
    extract::{DefaultBodyLimit, Json},
    http::StatusCode,
    response::Redirect,
    routing::{get, post},
    Router,
};
use base64::{engine::general_purpose, Engine as _};
use serde::{Deserialize, Serialize};
use std::{fs, process::Command};
use tempfile::tempdir;
use tower_http::services::ServeDir;

#[derive(Deserialize)]
struct Save2Json {
    binfile: String,
    slot: u32,
}

#[derive(Deserialize)]
struct Json2Save {
    binfile: String,
    jsonfile: String,
    slot: u32,
}

#[derive(Serialize)]
struct GenericResponse {
    status: String,
    payload: String,
}

const BIN_PATH: &str = "./mh3se-cli";
const MAX_SAVE_BYTES: usize = 16 * 1024 * 1024;

fn check_slot(slot: u32) -> Result<(), StatusCode> {
    if slot > 2 { Err(StatusCode::BAD_REQUEST) } else { Ok(()) }
}

fn decode_upload(encoded: &str) -> Result<Vec<u8>, StatusCode> {
    let bytes = general_purpose::STANDARD
        .decode(encoded)
        .map_err(|_| StatusCode::BAD_REQUEST)?;
    if bytes.is_empty() || bytes.len() > MAX_SAVE_BYTES {
        return Err(StatusCode::PAYLOAD_TOO_LARGE);
    }
    Ok(bytes)
}

async fn save2json(Json(payload): Json<Save2Json>) -> Result<Json<GenericResponse>, StatusCode> {
    check_slot(payload.slot)?;
    let bin_data = decode_upload(&payload.binfile)?;
    let workdir = tempdir().map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    let bin_path = workdir.path().join("input-save.bin");
    let json_path = workdir.path().join("decoded.json");
    fs::write(&bin_path, bin_data).map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let output = Command::new(BIN_PATH)
        .arg("decode")
        .arg(&bin_path)
        .arg(&json_path)
        .arg(payload.slot.to_string())
        .output()
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    if !output.status.success() {
        return Ok(Json(GenericResponse {
            status: "ERR".to_string(),
            payload: String::from_utf8_lossy(&output.stderr).to_string(),
        }));
    }
    let json_output = fs::read_to_string(&json_path).map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    Ok(Json(GenericResponse {
        status: String::from_utf8_lossy(&output.stdout).trim().to_string(),
        payload: json_output,
    }))
}

async fn json2save(Json(payload): Json<Json2Save>) -> Result<Json<GenericResponse>, StatusCode> {
    check_slot(payload.slot)?;
    let bin_data = decode_upload(&payload.binfile)?;
    if payload.jsonfile.len() > 8 * 1024 * 1024 {
        return Err(StatusCode::PAYLOAD_TOO_LARGE);
    }

    let workdir = tempdir().map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    let bin_path = workdir.path().join("original-save.bin");
    let json_path = workdir.path().join("edited-save.json");
    let out_path = workdir.path().join("edited-save.bin");
    fs::write(&bin_path, bin_data).map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    fs::write(&json_path, payload.jsonfile).map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let output = Command::new(BIN_PATH)
        .arg("encode")
        .arg(&json_path)
        .arg(&bin_path)
        .arg(&out_path)
        .arg(payload.slot.to_string())
        .output()
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    if !output.status.success() {
        return Ok(Json(GenericResponse {
            status: "ERR".to_string(),
            payload: String::from_utf8_lossy(&output.stderr).to_string(),
        }));
    }
    let out_bin = fs::read(&out_path).map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    Ok(Json(GenericResponse {
        status: String::from_utf8_lossy(&output.stdout).trim().to_string(),
        payload: general_purpose::STANDARD.encode(out_bin),
    }))
}

#[tokio::main]
async fn main() {
    let port: u16 = std::env::var("PORT")
        .ok()
        .and_then(|value| value.parse().ok())
        .unwrap_or(8888);

    let app = Router::new()
        .route("/", get(|| async { Redirect::temporary("/web/index.html") }))
        .route("/save2json", post(save2json))
        .route("/json2save", post(json2save))
        .nest_service("/web", ServeDir::new("web"))
        .layer(DefaultBodyLimit::max(32 * 1024 * 1024));

    let address = format!("0.0.0.0:{port}");
    let listener = tokio::net::TcpListener::bind(&address)
        .await
        .expect("could not bind web server");
    println!("MH3SE online server listening on {address}");
    axum::serve(listener, app).await.expect("web server failed");
}
